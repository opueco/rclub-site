normalizePath("~")
